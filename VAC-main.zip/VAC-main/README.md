To open the quiz application in browser click on the following link
https://tanvijain0.github.io/VAC/Quiz-Application/



To open the pokemon app use the following link
https://tanvijain0.github.io/VAC/Pokemon-App/
